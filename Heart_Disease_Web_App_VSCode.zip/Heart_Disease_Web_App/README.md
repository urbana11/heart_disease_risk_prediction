# Heart Disease Risk Prediction — Flask Web Application

A responsive demonstration interface for the existing Logistic Regression classifier trained on the Cleveland heart disease dataset (303 records, 13 clinical input features). The previously reported held-out accuracy is **80.33%**. This is a research demonstration, **not a diagnostic medical device**.

## Setup (Windows / VS Code)

Use **Python 3.10** to maximize compatibility with the supplied scikit-learn 1.2.2 model. Open this folder in VS Code, then run in PowerShell:

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py
```

This avoids PowerShell's script activation policy. If `py -3.10` fails, install Python 3.10 and retry. On macOS/Linux use `python3 -m venv .venv`, then `.venv/bin/python -m pip install -r requirements.txt` and `.venv/bin/python app.py` (the model's original dependency versions may need a compatible environment).

Open **http://127.0.0.1:5000** in a browser.

## Files

- `app.py` — Flask application, JSON validation, model inference
- `prediction_model.pkl` — the existing trained model (do not load untrusted pickle files)
- `templates/index.html` — web interface
- `static/style.css` — responsive styling
- `static/script.js` — form submission and result rendering
- `heart_disease_data.csv` — original project dataset (not used by the API at runtime)
- `heartDiseases.ipynb` — original training notebook (not used by the API at runtime)

## API

- `GET /` — web application
- `GET /test` — API health check
- `POST /predict` — JSON with the 13 input features; returns `prediction` (0 or 1), `label`, `message`, and `probability_percent` when supported by the model.

The interface uses dataset-observed ranges as a simple input check, not as medical thresholds. The CSV contains `ca=4` and `thal=0` in some records; these are supported for consistency with the trained model. Clinical categories follow the project dataset coding; consult the dataset's documentation before using clinical labels outside this demonstration.

## Notes

- No external patient information is saved by the application.
- The model's probability is a statistical estimate, not a clinically calibrated risk score.
- Do not enable Flask debug mode or use the development server for public deployment.

### Authors

Umme Ara Urbana (22201216) and Tabeeb Tazwar Ahmad (22201218)  
Department of Computer Science and Engineering, University of Asia Pacific, Dhaka, Bangladesh.
