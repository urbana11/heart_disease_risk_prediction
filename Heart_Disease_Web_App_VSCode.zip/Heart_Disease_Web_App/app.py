"""Flask interface for the existing Cleveland heart disease classification model."""
from pathlib import Path
import pickle

import pandas as pd
from flask import Flask, jsonify, render_template, request

BASE_DIR = Path(__file__).resolve().parent
app = Flask(__name__)
FEATURES = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']
# Ranges reflect observed values in the provided Cleveland CSV, not clinical safety limits.
RULES = {
    'age': (29, 77), 'sex': (0, 1), 'cp': (0, 3),
    'trestbps': (94, 200), 'chol': (126, 564), 'fbs': (0, 1),
    'restecg': (0, 2), 'thalach': (71, 202), 'exang': (0, 1),
    'oldpeak': (0, 6.2), 'slope': (0, 2), 'ca': (0, 4), 'thal': (0, 3)
}
CATEGORICAL = {'sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal'}
INTEGER = CATEGORICAL | {'age', 'trestbps', 'chol', 'thalach'}

# Only load model files that you trust. Pickle is not safe for untrusted files.
with (BASE_DIR / 'prediction_model.pkl').open('rb') as f:
    model = pickle.load(f)


@app.get('/')
def home():
    return render_template('index.html')


@app.get('/test')
def test():
    return jsonify(message='Welcome to Flask API', status='ok')


@app.post('/predict')
def predict():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(error='Please send a JSON object containing 13 clinical fields.'), 400
    missing = [f for f in FEATURES if f not in data or data[f] in (None, '')]
    extra = [k for k in data if k not in FEATURES]
    if missing or extra:
        return jsonify(error='Invalid feature set.', missing=missing, unexpected=extra), 400
    clean = {}
    errors = {}
    for name in FEATURES:
        try:
            raw = data[name]
            if isinstance(raw, bool):
                raise ValueError()
            value = float(raw)
            if not (float('-inf') < value < float('inf')):
                raise ValueError()
            low, high = RULES[name]
            if not (low <= value <= high):
                errors[name] = f'Enter a value from {low} to {high}.'
            elif name in INTEGER and not value.is_integer():
                errors[name] = 'Enter a whole number.'
            else:
                clean[name] = int(value) if name in INTEGER else value
        except (ValueError, TypeError, OverflowError):
            errors[name] = 'Enter a valid number.'
    if errors:
        return jsonify(error='Please correct the highlighted fields.', fields=errors), 400

    frame = pd.DataFrame([[clean[f] for f in FEATURES]], columns=FEATURES)
    try:
        predicted = int(model.predict(frame)[0])
        probability = None
        if hasattr(model, 'predict_proba'):
            classes = list(model.classes_)
            if 1 in classes:
                probability = round(float(model.predict_proba(frame)[0][classes.index(1)]) * 100, 1)
    except Exception:
        app.logger.exception('Model inference failed')
        return jsonify(error='Prediction could not be completed. Check model compatibility.'), 500
    return jsonify(prediction=predicted,
                   label='Heart disease indicated' if predicted == 1 else 'Heart disease not indicated',
                   probability_percent=probability,
                   message='The Person has Heart Disease' if predicted == 1 else 'The Person does not have a Heart Disease',
                   disclaimer='Educational demonstration only. This is not a medical diagnosis.')


if __name__ == '__main__':
    app.run(debug=False)
