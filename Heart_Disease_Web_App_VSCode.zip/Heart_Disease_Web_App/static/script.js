const form = document.querySelector('#prediction-form');
const errorBox = document.querySelector('#form-error');
const submitButton = document.querySelector('#submit-button');
const fields = ['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal'];
const resultEmpty = document.querySelector('#result-empty');
const resultContent = document.querySelector('#result-content');
function resetFeedback(){errorBox.hidden=true;errorBox.textContent='';document.querySelectorAll('.invalid').forEach(el=>el.classList.remove('invalid'));}
form.addEventListener('submit',async(event)=>{
 event.preventDefault();resetFeedback();
 const payload={};let invalid=false;
 for(const key of fields){const input=form.elements[key];if(!input.value.trim()||!input.checkValidity()){input.classList.add('invalid');invalid=true;}payload[key]=Number(input.value);}
 if(invalid){errorBox.textContent='Please enter valid values in all fields.';errorBox.hidden=false;return;}
 submitButton.disabled=true;submitButton.textContent='Predicting…';
 try{
  const response=await fetch('/predict',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const result=await response.json();
  if(!response.ok){if(result.fields)Object.keys(result.fields).forEach(key=>form.elements[key]?.classList.add('invalid'));throw new Error(result.error||'Prediction failed.');}
  resultEmpty.hidden=true;resultContent.hidden=false;
  const badge=document.querySelector('#result-badge');badge.className='result-badge'+(result.prediction===1?' positive':'');
  badge.textContent=result.prediction===1?'POSITIVE CLASSIFICATION':'NEGATIVE CLASSIFICATION';
  document.querySelector('#result-title').textContent=result.label;
  document.querySelector('#result-probability').textContent=result.probability_percent===null?'Probability not available.':`Model-estimated probability of class 1: ${result.probability_percent}%`;
  resultContent.scrollIntoView({behavior:'smooth',block:'nearest'});
 }catch(err){errorBox.textContent=err.message;errorBox.hidden=false;}
 finally{submitButton.disabled=false;submitButton.innerHTML='♥ &nbsp; Predict heart disease';}
});
form.addEventListener('reset',()=>{resetFeedback();resultContent.hidden=true;resultEmpty.hidden=false;});
